import java.util.Scanner;



public class Main {



    public static void main(String[] args) {



        Scanner in = new Scanner(System.in);



        User user = new User("Ali", 101, "Student");



        Exam exam = new Exam("Java Basics") {

            public void takeExam() {

                System.out.println("Exam Started...");

                System.out.println("Answer the following questions:");

                showQuestions();

            }

        };



        exam.addQuestion("What is OOP?");

        exam.addQuestion("Define Inheritance in Java.");

        exam.addQuestion("What is the difference between class and object?");



        boolean running = true;



        while (running) {



            System.out.println("\n--- Electronic Exam System ---");

            System.out.println("1. Show My Info");

            System.out.println("2. Show Exam Questions");

            System.out.println("3. Start Exam");

            System.out.println("4. Exit");

            System.out.print("Enter your choice: ");



            int choice = in.nextInt();

            in.nextLine();



            if (choice == 1) {

                user.showInfo();

            }



            else if (choice == 2) {

                exam.showQuestions();

            }



            else if (choice == 3) {

                exam.takeExam();

            }



            else if (choice == 4) {

                running = false;

                System.out.println("Exiting system...");

            }



            else {

                System.out.println("Invalid choice!");

            }

        }



        in.close();

    }

}