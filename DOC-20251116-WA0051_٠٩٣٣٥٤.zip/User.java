public class User {

    private String name;

    private int id;

    private String role;



    public User(String name, int id, String role) {

        this.name = name;

        this.id = id;

        this.role = role;

    }



    public String getName() {

        return name;

    }



    public int getId() {

        return id;

    }



    public String getRole() {

        return role;

    }



    public void showInfo() {

        System.out.println("Name: " + name);

        System.out.println("ID: " + id);

        System.out.println("Role: " + role);

    }

}